import java.util.*;
public class Complex_Demo {

	public static void main(String[] args) 
	{
		
		 		int r1,i1,r2,i2;
		 		int ch = 0;
		 		
		 		Scanner sc = new Scanner(System.in);
		 		
		 		System.out.println("Enter Real no.:");
				r1=sc.nextInt();
				
				System.out.println("Enter Img no.:");
				i1=sc.nextInt();
				
				System.out.println("Enter Real no.:");
				r2=sc.nextInt();
				
				System.out.println("Enter Img no.:");
				i2=sc.nextInt();
		 		
		        Complex c1 = new Complex(r1,i1);
		 		Complex c2 = new Complex(r2,i2);
		 		Complex c3 = new Complex();
		 		
		 	
		 		System.out.println("First:");
		 		c1.display();
		 		
		 		System.out.println("Second:");
		 		c2.display();

		 	do 
			{  
		 		System.out.println();
		 		System.out.println("-----------------------------------------------------------------------------------------------!");
		 		System.out.println("1.Addition");
				System.out.println("2.Subtraction:");
				System.out.println("3.Multiplication:");
				System.out.println("4.Division");
				System.out.println("5.Exit");
				
				
				System.out.println("Choice:");
				ch = sc.nextInt();
				System.out.println();
				
				switch(ch)
				{  
					case 1 : System.out.println("Addition: ");
						 	 c3.add(c1, c2);
						 	 c3.display();
						 	 break ;
				
					case 2 : System.out.println("Subtraction: ");
						 	 c3.subtract(c1, c2);
						 	 c3.display();
						 	 break ;
						 
					case 3 : System.out.println("Multiplication: ");
					  	 	 c3.multiply(c1, c2);
					  	 	 c3.display();
					  	 	 break ;
					  	 
					case 4 : System.out.println("Division: ");
						 	 c3.divide(c1, c2);
						 	 c3.display();
						 	 break ;
			
					case 5 : System.out.println("Exit");
				  		 	 break ;
				
				}
			
			} while(ch!=5);	
			
		}
			
	}

/*
output:
Enter Real no.:
20
Enter Img no.:
15
Enter Real no.:
10
Enter Img no.:
5
First:
20.0+15.0i
Second:
10.0+5.0i

-----------------------------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Division
5.Exit
Choice:
1

Addition: 
30.0+20.0i

-----------------------------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Division
5.Exit
Choice:
2

Subtraction: 
10.0+10.0i

-----------------------------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Division
5.Exit
Choice:
3

Multiplication: 
125.0+250.0i

-----------------------------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Division
5.Exit
Choice:
4

Division: 
2.2+0.4i

-----------------------------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Division
5.Exit
Choice:
5

Exit
*/
