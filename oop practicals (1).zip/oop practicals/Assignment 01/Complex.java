
public class Complex
{

	          private double real;
	          private double img;
	          
	          public Complex()
	          { 
	        	  real=img=0;
	          }  
	  
	          public  Complex(double real,double img)
	          {
	        	  	this.real = real;
	        	  	this.img =img;
	          }

	          public void add(Complex c1,Complex c2)
	          { 
	        	  	real = c1.real + c2.real;
	        	  	img = c1.img + c2.img;
	          }
	          
	          public void subtract(Complex c1,Complex c2)
	          { 
	        	  real = c1.real - c2.real;
	        	  img = c1.img - c2.img;
	          }
		
	          public void multiply(Complex c1,Complex c2)
	          { 
	        	 real = ((c1.real*c2.real)-(c1.img*c2.img));
	        	 img = ((c1.real*c2.img)+(c1.img*c2.real));
	        	 
	        	 // (c1.real+c1.img)(c2.real+c2.img)=((c1.real*c2.real)-(c1.img*c2.img))+((c1.real*c2.img)+(c1.img*c2.real))i;
	        	 // formula =Complex no. = c1*c2=[[c1R*c2R]-[c1I*c2I]]=REAL NO.
	        	 //          Complex no. = c1*c2=[[c1R*c2I]+[c1I*c2R]]=IMG NO.
	          }
	          
	          public void divide(Complex c1,Complex c2)
	          { 
	        	  real=((c1.real*c2.real)+(c1.img*c2.img))/((c2.real*c2.real)+(c2.img*c2.img));
	        	  img =((c1.img*c2.real)-(c1.real*c2.img))/((c2.real*c2.real)+(c2.img*c2.img));
	        	  
	        	  // c1/c2=[c1.real*c2.real]+[c1.img*c2.img]/[[c2.real*c2.real]+[c2.img*c2.img]]=real no.
	        	  		 //[[c1.img*c2.real]-[c1.real*c2.img]]/[[c2.real*c2.real]+[c2.img*c2.img]]=img no.  	  
	          }

			
			 public void display()
		     { 
		    	  System.out.println(real+"+"+img+"i");
		    	  
		     }
			
			  
		} 


