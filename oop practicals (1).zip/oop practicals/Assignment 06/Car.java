public class Car implements Vehicle
{
	private int newgear;
    private int speed;

    public void changeGear(int gear) {
        newgear = gear;
        System.out.println("Car: Changed gear to " + newgear);
    }

    public void speedUp(int s) {
        speed += s;
        System.out.println("Car: Speed increased to " + speed + " km/h");
    }

    public void applyBrakes(int b) {
        speed -= b;
        System.out.println("Car: Applied brakes. Current speed: " + speed + " km/h");
    }
}
