import java.util.*;
public class Main_interface 
{

	public static void main(String[] args) 
	{
		
		Vehicle bicycle = new Bicycle();
        Vehicle bike = new Bike();
        Vehicle car = new Car();

        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter gear for bicycle:");
        a = sc.nextInt();
        System.out.println("Enter speed for bicycle:");
        b = sc.nextInt();
        System.out.println("Enter brake for bicycle:");
        c= sc.nextInt();
        
        bicycle.changeGear(a);
        bicycle.speedUp(b);
        bicycle.applyBrakes(c);

        System.out.println("Enter gear for bike:");
        a = sc.nextInt();
        System.out.println("Enter speed for bike:");
        b = sc.nextInt();
        System.out.println("Enter brake for bike:");
        c= sc.nextInt();
        
        bike.changeGear(a);
        bike.speedUp(b);
        bike.applyBrakes(c);
        
        System.out.println("Enter gear for car:");
        a = sc.nextInt();
        System.out.println("Enter speed for car:");
        b = sc.nextInt();
        System.out.println("Enter brake for car:");
        c= sc.nextInt();

        car.changeGear(a);
        car.speedUp(b);
        car.applyBrakes(c);
	}

}

/*
 output:
 Enter gear for bicycle:
2
Enter speed for bicycle:
40
Enter brake for bicycle:
3
Bicycle: Changed gear to 2
Bicycle: Speed increased to 40 km/h
Bicycle: Applied brakes. Current speed: 37 km/h
Enter gear for bike:
4
Enter speed for bike:
60
Enter brake for bike:
2
Bike: Changed gear to 4
Bike: Speed increased to 60 km/h
Bike: Applied brakes. Current speed: 58 km/h
Enter gear for car:
4
Enter speed for car:
100
Enter brake for car:
2
Car: Changed gear to 4
Car: Speed increased to 100 km/h
Car: Applied brakes. Current speed: 98 km/h
  */
