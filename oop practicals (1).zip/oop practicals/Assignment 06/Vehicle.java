public interface Vehicle {

	 void changeGear(int gear);
	    void speedUp(int s);
	    void applyBrakes(int b);
}
