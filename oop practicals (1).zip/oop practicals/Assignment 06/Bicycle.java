
public class Bicycle implements Vehicle
{
	private int newgear;
    private int speed;

    public void changeGear(int gear) {
        newgear = gear;
        System.out.println("Bicycle: Changed gear to " + newgear);
    }

    public void speedUp(int s) {
        speed += s;
        System.out.println("Bicycle: Speed increased to " + speed + " km/h");
    }

    public void applyBrakes(int b) {
        speed -= b;
        System.out.println("Bicycle: Applied brakes. Current speed: " + speed + " km/h");
    }
}
