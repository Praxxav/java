
public class Bike implements Vehicle
{

	private int newgear;
    private int speed;

    public void changeGear(int gear) {
        newgear = gear;
        System.out.println("Bike: Changed gear to " + newgear);
    }

    public void speedUp(int s) {
        speed += s;
        System.out.println("Bike: Speed increased to " + speed + " km/h");
    }

    public void applyBrakes(int b) {
        speed -= b;
        System.out.println("Bike: Applied brakes. Current speed: " + speed + " km/h");
    }
}

