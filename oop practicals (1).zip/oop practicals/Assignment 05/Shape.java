
abstract public class Shape 
{
	protected int a;
	
	abstract void compute_area();
}
