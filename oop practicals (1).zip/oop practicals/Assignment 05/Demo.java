import java.util.*;
public class Demo {

	public static void main(String[] args) {
		
		int c;
		Shape s;
		Scanner sc = new Scanner(System.in);
		
		do
		{
			System.out.println("1. Area of Circle");
			System.out.println("2. Area of Rectangle");
			System.out.println("3. Area of Triangle");
			System.out.println("4. Exit");
			System.out.println();
			
			System.out.println("Enter the choice:");
			c=sc.nextInt();
			
			switch(c)
			{
				case 1: Circle c1 = new Circle();
						s=c1;
				
						c1.accept1();
						s.compute_area();
						c1.display1();
						break;
						
				case 2: Rectangle r1 = new Rectangle();
				
				        s=r1;
				
						r1.accept2();
						s.compute_area();
						r1.display2();
						break;
						
				case 3: Triangle t1 = new Triangle();
				
						s=t1;
						
						t1.accept3();
						s.compute_area();
						t1.display3();
						break;
			}
			
			System.out.println("------------------------------------------!");
			
		}while(c!=4);	
	}

}

/*
 Output:
 1. Area of Circle
2. Area of Rectangle
3. Area of Triangle
4. Exit

Enter the choice:
1
Enter the Radius:
24
Area of circle :1808.6399999999999
------------------------------------------!
1. Area of Circle
2. Area of Rectangle
3. Area of Triangle
4. Exit

Enter the choice:
2
Enter the length:
10
Enter the breadth:
20
Area of rectangle :200.0
------------------------------------------!
1. Area of Circle
2. Area of Rectangle
3. Area of Triangle
4. Exit

Enter the choice:
3
Enter the base:
20
Enter the height:
30
Area of triangle :300.0
------------------------------------------!
1. Area of Circle
2. Area of Rectangle
3. Area of Triangle
4. Exit

Enter the choice:
4
------------------------------------------!


*/