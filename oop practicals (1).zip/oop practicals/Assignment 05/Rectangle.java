import java.util.*;
public class Rectangle extends Shape
{
	private double area;
	private int b;
	
	public void accept2()
	{
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Enter the length:");
		a = sc.nextInt();
		
		System.out.println("Enter the breadth:");
		b = sc.nextInt();
		
	}
	
	public void compute_area()
	{
		area = a*b;
		
	}
	
	public void display2()
	{
		System.out.println("Area of rectangle :"+area);
		
	}
}
