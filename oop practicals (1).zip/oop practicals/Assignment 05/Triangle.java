import java.util.*;
public class Triangle extends Shape
{
	private double area;
	private int h;
	
	public void accept3()
	{
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Enter the base:");
		a = sc.nextInt();
		
		System.out.println("Enter the height:");
		h = sc.nextInt();
		
	}
	
	public void compute_area()
	{
		area = 0.5*a*h;
		
	}
	
	public void display3()
	{
		System.out.println("Area of triangle :"+area);
		
	}

}
