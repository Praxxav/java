import java.util.*;
public class Circle extends Shape
{
	private double area;
	
	public void accept1()
	{
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Enter the Radius:");
		a = sc.nextInt();
		
	}
	
	public void compute_area()
	{
		area = 3.14*a*a;
		
	}
	
	public void display1()
	{
		System.out.println("Area of circle :"+area);
		
	}
}
