import java.util.*; 
 
public class File_Main 
{

	public static void main(String[] args) 
	{
		

		File_Operation f = new File_Operation(); 
		Scanner sc =new Scanner(System.in);
		System.out.println("");
		try
		{
			
		
		while(true)
		{
			
		System.out.print("1. Add Records\n2. Display Records\n3. Clear All Records\n4. Search Records"
				+ "\n5. Delete Records\n6. Update Records \n7. Exit\n\nEnter your choice : ");
		int choice = sc.nextInt();
		System.out.println("");
		
		
		switch(choice)  {   
		case 1:  
			f.addRecords();  
			System.out.println("\n====================================================\n");
			break;  
			
		case 2:  	
			f.readRecords();  
			System.out.println("\n====================================================\n");
			break;  
			
		case 3:  
			f.clear("sample.txt"); 
			System.out.println("\n====================================================\n");
			break;
			
		case 4:   
			f.searchRecords(); 
			System.out.println("\n====================================================\n");
			break; 
			
		case 5:    
			f.deleteRecords();
			System.out.println("\n====================================================\n");
			break;    
		
		case 6:    
			f.updateRecords(); 
			System.out.println("\n====================================================\n");
			break;  
			
		case 7:  
			System.out.println("\n====================================================\n");
			System.exit(0);
			break;  
			
		default:  
			System.out.println("\nInvalid Choice !"); 
			System.out.println("\n====================================================\n");
			break; 
			} 
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}    
	}

/*
 output: 
 
1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 1


Enter Student Name: abc
Student Id: 1
Roll no: 23
Address: lmn
Class: 2
Marks : 98

Records added successfully !

Do you want to add more records ? (y/n) : y


Enter Student Name: xyz
Student Id: 2
Roll no: 45
Address: pqr
Class: 6
Marks : 99

Records added successfully !

Do you want to add more records ? (y/n) : y


Enter Student Name: ijk
Student Id: 3
Roll no: 67
Address: uvw
Class: 3
Marks : 87

Records added successfully !

Do you want to add more records ? (y/n) : n

====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 2

abc 121 123 pune 2 12.0

xyz 345 454 pqr 5 67.0

abc 1 23 lmn 2 98.0

xyz 2 45 pqr 6 99.0

ijk 3 67 uvw 3 87.0


====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 4

Enter an id of the student you want to search: 121
Record found
abc 121 123 pune 2 12.0


====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 5

Enter the name of the student you want to delete: abc
Record found
Record found
deleted successfully
Renamed successfully

====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 2

xyz 345 454 pqr 5 67.0

xyz 2 45 pqr 6 99.0

ijk 3 67 uvw 3 87.0


====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 6

Enter the name of the student you want to update: xyz
Record found
Enter updated marks: 78
Record found
Enter updated marks: 99
record updated successfully
Renamed successfully

====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 2

xyz 345 454 pqr 5 78

xyz 2 45 pqr 6 99

ijk 3 67 uvw 3 87.0


====================================================

1. Add Records
2. Display Records
3. Clear All Records
4. Search Records
5. Delete Records
6. Update Records 
7. Exit

Enter your choice : 7


====================================================


 */
