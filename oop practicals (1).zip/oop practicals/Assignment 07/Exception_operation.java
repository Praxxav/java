import java.util.*;
public class Exception_operation 
{
	private int a,b,c = 0;
	private String d;
	
	public void Division_Exception()
	{	
		//int a,b,c = 0;
		
		try
		{
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter num1:");
			a = sc.nextInt();
			
			System.out.println("Enter num2:");
			b = sc.nextInt();
			
			c=a/b;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
			
		}
		
		finally
		{
			System.out.println("Result:"+c);
			System.out.println("Exception Handled successfully!");
		}
	}
	
	public void inputmismatch_Exception()
	{
		//int a,b,c = 0;
		
		try
		{
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter num1:");
			a = sc.nextInt();
			
			System.out.println("Enter num2:");
			b = sc.nextInt();
			
			c=a+b;
		}
		catch(InputMismatchException e)
		{
			System.out.println(e.getMessage());
			System.out.println("Result:"+c);
		}
		
		finally
		{
			System.out.println("Exception Handled successfully!");
		}
		
	}
	
	public void Nullpointer_Exception()
	{
		//String d;
		
		try
		{
			d = null;
			System.out.println(d.length());
		}
		catch(NullPointerException e)
		{
			System.out.println(e.getMessage());
			//System.out.println("length of string :"+ c.length());
		}
		
		finally
		{
			System.out.println("NullPointerException Handled successfully!");
		}
	}
	
	public void ArrayOutOfBound_Exception()
	{
		try
		{
			
		String[] arr = {"apple","mango","grapes","watermelon"};   
		                               
		        for(int i=0;i<=arr.length;i++) 
		        {  
		             System.out.println(arr[i]);      
		        }
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("Exception Handled successfully!");
		}
	}
}