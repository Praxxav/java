import java.util.*;
public class handled_exception {

	public static void main(String[] args) 
	{
		
		int ch;
		
		Exception_operation e1 = new Exception_operation();
		
		Scanner sc = new Scanner(System.in);
		
		do
		{
			System.out.println("1. Arithmetic_Exception");
			System.out.println("2. Input/Output_Exception");
			System.out.println("3. Nullpointer_Exception");
			System.out.println("4. ArrayOutOfBound_Exception");
			
			System.out.println("Enter the choices :");
			ch=sc.nextInt();
			
			switch(ch)
			{
				 case 1: System.out.println("Arithmetic_Exception");
				 		 e1.Division_Exception();
				 		 break;
				 		 
				 case 2: System.out.println("Input_Mismatch_Exception");
				 		 e1.inputmismatch_Exception();
				 		 break;
				 		 
				 case 3: System.out.println("Nullpointer_Exception");
				 		 e1.Nullpointer_Exception();
				 		 break;
				 		 
				 case 4: System.out.println("ArrayIndexOutOfBound_Exception");
				 		 e1.ArrayOutOfBound_Exception();
				 		 break;
			}
			
			System.out.println("---------------------------------------!");
			
		}while(ch!=5);
	}

}
