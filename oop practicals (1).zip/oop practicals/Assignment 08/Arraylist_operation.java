
import java.util.*;
public class Arraylist_operation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner (System.in);
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		ArrayList<Integer> even = new ArrayList<Integer>();
		
		ArrayList<Integer> odd = new ArrayList<Integer>();
		
		ArrayList<Integer> Prime = new ArrayList<Integer>();
		
		ArrayList<String> palindrom = new ArrayList<String>();
		
		ArrayList<String> word = new ArrayList<String>();
		
		int element;
		int num, count=0;
		String alpha = null, reverse = null;
		
		System.out.println("Element:");
		
		element = sc.nextInt();
		
		for(int i=0; i<element ; i++)
		{
			num = sc.nextInt();
			list.add(num);
		}
		
		for(int i=0; i<list.size(); i++)
		{
			if(list.get(i)%2==0)
			{
				even.add(list.get(i));
			}
			
			else
			{
				odd.add(list.get(i));
				
			}
			
			System.out.println("Even:"+even);
			System.out.println("Odd:"+odd);
		}
		
		int flag;
		
		for( int i=0; i< list.size();i++)
		{
			flag=0;
			
			for(int j=2;j<list.get(i);j++)
			{
				if(list.get(i)%j==0)
				{
					flag=1;
					break;
				}
			}
			
			if(flag==0)
			{
				Prime.add(list.get(i));
			}
			
			System.out.println("Prime:"+Prime);
		}
		
		//palindrom
		
				int n1, flagz;
				String s1;
				System.out.println("Enter no. of strings to be entered: ");
				n1=sc.nextInt();
				
				for(int i=0; i<n1; i++)
				{
					s1= sc.next();
					word.add(s1);
				}
				
				for(int i=0; i<word.size();i++)
				{
					flagz=1;
					String s2= word.get(i);
					
					for(int j=0; j<s2.length();j++)
					{
						if(s2.charAt(i)!= s2.charAt(s2.length()-i-1))
						{
							flag=0;
							break;
						}
					}
					if(flagz==1)
					{
						palindrom.add(word.get(i));
					}
				}
				
				System.out.println("String entered: "+word);
				System.out.println("Palindrom: "+palindrom);
				
			}


	}

