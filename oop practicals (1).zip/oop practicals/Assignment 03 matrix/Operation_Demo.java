import java.util.*;
public class Operation_Demo {

	public static void main(String[] args) {
		

		int x,y,u,v;
		int ch=0;
	
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the no. of rows: ");
		x=sc.nextInt();
	
		System.out.println("Enter the no. of columns: ");
		y=sc.nextInt();
		
		
		Operation m1 = new Operation(x,y);
		
		m1.display();
		
		System.out.println("Enter the no. of rows: ");
		u=sc.nextInt();
	
		System.out.println("Enter the no. of columns: ");
		v=sc.nextInt();
		
		Operation m2 = new Operation(u,v);
		
		m2.display();
		
		Operation m3 = new Operation(0,0);
		
		do 
		{  
			System.out.println();
			System.out.println("--------------------------------------------------------------------------!");
			System.out.println("1.Addition");
			System.out.println("2.Subtraction:");
			System.out.println("3.Multiplication:");
			System.out.println("4.Transpose");
			System.out.println("5.Addition_Diagonal");
			System.out.println("6.Upper_Diagonal_Addition");
			System.out.println("7.Lower_Diagonal_Addition");
			System.out.println("8.Exit");
			
			System.out.println("Choice:");
			ch = sc.nextInt();
			System.out.println();
			
			switch(ch)
			{  
				case 1 : System.out.println("Addition: ");
						 m3.add(m1,m2);
						 m3.display();
					 	 break ;
			
				case 2 : System.out.println("Subtraction: ");
						 m3.subtract(m1, m2);
						 m3.display();
					 	 break ;
					 
				case 3 : System.out.println("Multiplication: ");
				         m3.multiply(m1, m2);
				         m3.display();
				  	 	 break ;
				  	 
				case 4 : System.out.println("Transpose: ");
				         m3.transpose(m1);
				         m3.display();
					 	 break ;
		
				case 5 : System.out.println("Diagonal_Addition: ");
				         m3.add_diagonal(m1);
					 	 break ;
					 	 
				case 6 : System.out.println("Upper_Diagonal_Addition: ");
				         m3.upper_diagonal(m1);
					 	 break ;
					 	 
				case 7 : System.out.println("Lower_Diagonal_Addition: ");
				         m3.lower_diagonal(m1);
				         break ;
				         
				case 8 : System.out.println("Exit");
			  		 	 break ;
			
			}
		
		} while(ch!=8);	
		
	}	

	}

/* output:
Enter the no. of rows: 
3
Enter the no. of columns: 
3
Enter the element of matrix: 
9
Enter the element of matrix: 
8
Enter the element of matrix: 
7
Enter the element of matrix: 
6
Enter the element of matrix: 
5
Enter the element of matrix: 
4
Enter the element of matrix: 
3
Enter the element of matrix: 
2
Enter the element of matrix: 
1
9  8  7  
6  5  4  
3  2  1  
Enter the no. of rows: 
2
Enter the no. of columns: 
2
Enter the element of matrix: 
3
Enter the element of matrix: 
4
Enter the element of matrix: 
5
Enter the element of matrix: 
6
3  4  
5  6  

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
1
Addition: 
12  12  7  
11  11  4  
3  2  1  

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
2
Subtraction: 
6  4  7  
1  -1  4  
3  2  1  

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
3
Multiplication: 
73  88  7  
44  53  4  
22  26  1  

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
4
Transpose: 
9  6  3  
8  5  2  
7  4  1  

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
5
Diagonal_Addition: 
Addition of the diagonal elements:15

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
6
Upper_Diagonal_Addition: 
Addition of the  upper diagonal elements:19

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
7
Lower_Diagonal_Addition: 
Addition of the diagonal elements:11

--------------------------------------------------------------------------!
1.Addition
2.Subtraction:
3.Multiplication:
4.Transpose
5.Addition_Diagonal
6.Upper_Diagonal_Addition
7.Lower_Diagonal_Addition
8.Exit
Choice:
8
Exit
*/
