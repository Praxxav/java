import java.util.*;
public class Operation {

	private int row,col;
	private int mat[][]=new int [5][5];
	
	Scanner sc = new Scanner(System.in);
	
	public Operation(int x, int y)
	{	
		
		//System.out.println("Enter the no. of rows: ");
		row=x;
	
		//System.out.println("Enter the no. of columns: ");
		col=y;

		for(int i=0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				System.out.println("Enter the element of matrix: ");
				mat[i][j]=sc.nextInt();
			
			}
		}
	}
	
	
	/*	public void getdata(){
			System.out.println("Enter the no. of rows: ");
			row=sc.nextInt();
			System.out.println("Enter the no. of columns: ");
			col=sc.nextInt();
			for(int i=0; i < row; i++){
			for(int j = 0; j < col; j++){
			System.out.println("Enter the element of matrix: ");
			mat[i][j]=sc.nextInt();}
			}
		}*/
	
		public void add (Operation r, Operation c)
		{
			row = r.row;
			col = r.col;
	    
				for(int i = 0; i < row; i++)
				{
	            for (int j = 0; j < col; j++) 
	            {
	                mat[i][j] = r.mat[i][j] + c.mat[i][j];
	                
	            }
	        }
		}
	        
		
		public void subtract(Operation a, Operation b)
		{
				row=a.row;
				col=a.col;
				
	        for(int i = 0; i < row; i++) 
	        {
	            for (int j = 0; j < col; j++)
	            {
	               mat[i][j] = a.mat[i][j] - b.mat[i][j];
	                
	            }
	        }   
		}
		
		public void multiply(Operation m, Operation n)
		{
		   row=m.row;
		   col=m.col;
		   
		   int c2=n.row;//r2=m.row;
			
	        for(int i = 0; i < row; i++) 
	        {
	            for (int j = 0; j < c2; j++) 
	            {
	                for (int k = 0; k < col; k++)
	                {
	                	mat[i][j] += m.mat[i][k] * n.mat[k][j];
	                }
	            }
	        }
		}
		
		public void transpose(Operation f)
		{
	        row=f.col;
	        col=f.row;	      
	        for(int i = 0; i < f.row; i++) 
	        {
	            for (int j = 0; j < f.col; j++) 
	            {
	                mat[j][i] = f.mat[i][j];
	            }
	        }
	      
		}
		
		public void display()
		{
			for(int c = 0; c < row; c++) 
	        {
	            for (int d = 0 ; d < col; d++)
	            {
	                System.out.print(mat[c][d]+"  ");
	            }
	            System.out.println();
	        }
		}
		
		public void add_diagonal(Operation Q)
		{
			row=Q.row;
			col=Q.col;
			int sum=0;
			if(row==col)
			{
				for(int i=0;i<row;i++)
				{
					for(int j=0;j<col;j++)
					{
						if(i==j)
						{
							sum=sum+Q.mat[i][j];
						}
					}
				}
				System.out.println("Addition of the diagonal elements:"+sum); 
			}
			
		}
		public void upper_diagonal(Operation Q)
		{
			row=Q.row;
			col=Q.col;
			int sum=0;
			if(row==col)
			{
				for(int i=0;i<row;i++)
				{
					for(int j=0;j<col;j++)
					{
						if(i < j)
						{
							sum=sum+Q.mat[i][j];
						}
					}
				}
				System.out.println("Addition of the  upper diagonal elements:"+sum); 
			}
			
		}
		
		public void lower_diagonal(Operation Q)
		{
			row=Q.row;
			col=Q.col;
			int sum=0;
			if(row==col)
			{
				for(int i=0;i<row;i++)
				{
					for(int j=0;j<col;j++)
					{
						if(i > j)
						{
							sum=sum+Q.mat[i][j];
						}
					}
				}
				System.out.println("Addition of the diagonal elements:"+sum); 
			}
			
		}
}
