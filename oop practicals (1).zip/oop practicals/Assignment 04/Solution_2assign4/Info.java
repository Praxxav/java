import java.util.Scanner;
public class Info {

	public static void main(String[] args) {
		
		//Employee e = new Employee();
	
		int ch;

	Scanner sc = new Scanner(System.in);
	
	do {
			
			System.out.println("Enter the choice to genarate details");
			System.out.println("1.Programmer");
			System.out.println("2.TeamLead");
			System.out.println("3.AssistantProjectManager");
			System.out.println("4.ProjectManager");
			System.out.println("5.Exit");
			
			System.out.println("Enter the choices:");
			ch=sc.nextInt();
			
			switch(ch)
			{
				case 1: Programmer p = new Programmer();
						p.Display();
						System.out.println();
						p.Display1();
						
						break;
				
				case 2: TeamLead tl = new TeamLead();
						tl.Display();
						System.out.println();
						tl.Display2();
						
						break;
						
				case 3: AssistantProjectManager ap = new AssistantProjectManager();
						ap.Display();
						System.out.println();
						ap.Display3();	
						
						break;
						
			    case 4: ProjectManager pm = new ProjectManager();
						pm.Display();
						System.out.println();
						pm.Display4();
						
						break;
				 
			}
			System.out.println("----------------------------------------------------------------!");
			
	}while(ch!=5);
	
		
	}

}

