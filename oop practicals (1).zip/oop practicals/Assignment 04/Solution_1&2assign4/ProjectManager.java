import java.util.*;
public class ProjectManager extends Employee 
{
	private double basic_pay, net_Salary, gross_Salary;//, DA, HRA, Funds, PF;
	
	public void getData4()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Basic_pay:");
		basic_pay=sc.nextInt();
	
	}
	
	public void Display4()
	{
		/*
		DA=(97/basic_pay)*100;
		HRA= (10/basic_pay)*100;
		Funds=(0.1/basic_pay)*100;
		PF=(12/basic_pay)*100;
		*/
		
		gross_Salary = basic_pay+((97/basic_pay)*100)+(10/basic_pay)*100;
		net_Salary = (0.1/basic_pay)*100+(12/basic_pay)*100;
		
		System.out.println("Project_Manager Salary Details:"); 
		System.out.println();
		System.out.println("Basic_pay:"+ basic_pay);
		System.out.println("Net_Salary:"+ net_Salary);
		System.out.println("Gross_Salary:"+ gross_Salary);
	}



}
