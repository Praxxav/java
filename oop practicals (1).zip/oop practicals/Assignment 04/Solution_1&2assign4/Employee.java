import java.util.*;
import java.io.*;
public class Employee 
{
	private String name, email_id, address,Mobile_no;
	private int Emp_id, date, year, month;
	
	
	
	public void getData()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the name of employee:");
		name=sc.next();
		
		System.out.println("Enter the email_id of employee:");
		email_id=sc.next();
		
		System.out.println("Enter the address of employee:");
		address=sc.next();
	
		System.out.println("Enter the Mobile no. of employee:");
		Mobile_no=sc.next();
		
		for(int i=0;i<Mobile_no.length();i++)
		{
			if(Character.isDigit(Mobile_no.charAt(i))==false || Mobile_no.length() != 10)
			{
				System.out.println("enter valid no.");
				System.out.println("Enter the Mobile no. of employee:");
				Mobile_no=sc.next();
			}
		}
		
		
		System.out.println("Enter the empolyee_id of employee:");
		Emp_id=sc.nextInt();
		
		date_valid();
		
	}

	public void date_valid()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the DateOfBirth of employee:");
		System.out.println("Date:");
		date=sc.nextInt();
		if (date>=32)
		{
			System.out.println("Invalid Date!");
			System.out.println("Date:");
			date=sc.nextInt();
		}
		
		System.out.println("Month:");
		month=sc.nextInt();
		if (month>12)
		{
			System.out.println("Invalid Month!");
			System.out.println("Month:");
			month=sc.nextInt();
		}
		
		if(month==2 || month==4 || month==6 || month==9 || month==11)
		{
			if (date>30)
			{
				System.out.println("Invalid Date! for entered month");
				System.out.println("Date:");
				date=sc.nextInt();
			}
			
		}
		
		System.out.println("Year:");
		year=sc.nextInt();
		
		if(month==2 && year%4==0)
		{
			if(date>=29)
			{
				System.out.println("Invalid Date!");
				date_valid();
			}
		}
	}
	
	public void Display()
	{
		System.out.println("Employee Details:"); 
		System.out.println();
		System.out.println("Id:"+ Emp_id);
		System.out.println("Name:"+ name);
		System.out.println("DateOfBirth:"+date+"/"+month+"/"+year);
		System.out.println("Mobile no.:"+ Mobile_no);
		System.out.println("Email-Id:"+ email_id);
		System.out.println("Address:"+ address);
	}

}
