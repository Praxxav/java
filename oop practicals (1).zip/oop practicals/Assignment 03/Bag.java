package Assignment_Bag;

//import Assignment_Bag;
import java.util.*;
public class Bag 
{
	private int wt;
	private String color;
	public int i=0;
	private static int total_weight;
	private static int total_objects;
	
	public Bag()
	{
		color="Red";
		wt=10;
		total_weight= total_weight+wt;
		total_objects= total_objects+1;
	}
	
	public Bag( String color, int wt)
	{
		this.color=color;
		this.wt=wt;
		total_weight= total_weight+wt;
		total_objects= total_objects+1;
	}
	
	public Bag(String color)
	{
		this.color=color;
		wt=10;
		total_weight= total_weight+wt;
		total_objects= total_objects+1;
	}
	
	public Bag(int wt)
	{
		color="Purple";
		this.wt=wt;
		total_weight= total_weight+wt;
		total_objects= total_objects+1;
	}
	
	public void display(int i)
	{
		i =i+1;
		System.out.println(i+"."+" "+"Colour: "+color+" and "+" "+"Weight: "+wt);
	}
	public static void output()
	{
		System.out.println("The total weight is:"+total_weight);
		System.out.println("The total no. of objects added are: "+total_objects);
	}
	
	public static void delete(Bag b[], int n)
	{
		
		Scanner sc = new Scanner(System.in);
		
		int delete_rec;
		
		System.out.println("Enter no. of record to be deleted");
		delete_rec = sc.nextInt();
		
		total_weight=total_weight-b[delete_rec-1].wt;
		
		for(int i=delete_rec; i<n; i++)
		{
			b[i-1]=b[i];
			
		}
		total_objects= total_objects-1;
		//n=n-1;
		
	}
	
}

