package Assignment_Bag;

import java.util.*;
public class Bag_Demo
{
	public static void main(String[] args)
	{
		Bag b1[] = new Bag[10];
		int ch1,ch2,n=0,w,i=0;
		String c;
		
		Scanner sc=new Scanner(System.in);
		do
		{
		System.out.println("1.Add");
		System.out.println("2.Display");
		System.out.println("3.Delete");
		System.out.println("4.Exit");
		System.out.println("Choice:");
		
		ch1=sc.nextInt();
		switch(ch1)
		{
			case 1:
					do
					{
						System.out.println("1.Both Default");
						System.out.println("2.Both From User");
						System.out.println("3.Weight");
						System.out.println("4.Colour");
						System.out.println("5.Exit");
						
						System.out.println("Choice:");
						ch2=sc.nextInt();
						
						switch(ch2)
						{
							case 1: b1[n]= new Bag();
									n=n+1;
									break;
							case 2:
									System.out.println("Weight");
									w=sc.nextInt();
									System.out.println("colour");
									c=sc.next();
									b1[n]=new Bag(c,w);
									n=n+1;
									break;
							case 3:
									System.out.println("Weight");
									w=sc.nextInt();
									b1[n]=new Bag(w);
									n = n + 1;
									break;
							case 4:
									System.out.println("colour");
									c=sc.next();
									b1[n]=new Bag(c);
									n = n + 1;
									break;
						}
					}while(ch2!=5);
					 break;
					 
			case 2: for(i=0;i<n;i++)
					{
						b1[i].display(i);
						Bag.output();
						System.out.println();
					}
					break;
			
			case 3: Bag.delete(b1, n);
					n = n - 1;
					System.out.println("Record deleted Successfully....!");
					break;
					
		 }
	 }while(ch1!=4);
  }
}
					
/*
Output:

1.Add
2.Display
3.Delete
4.Exit
Choice:
1
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
1
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
1
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
2
Weight
10
colour
green
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
3
Weight
30
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
4
colour
yellow
1.Both Default
2.Both From User
3.Weight
4.Colour
5.Exit
Choice:
5
1.Add
2.Display
3.Delete
4.Exit
Choice:
2
1. Colour: Red and  Weight: 10
The total weight is:70
The total no. of objects added are: 5

2. Colour: Red and  Weight: 10
The total weight is:70
The total no. of objects added are: 5

3. Colour: green and  Weight: 10
The total weight is:70
The total no. of objects added are: 5

4. Colour: Purple and  Weight: 30
The total weight is:70
The total no. of objects added are: 5

5. Colour: yellow and  Weight: 10
The total weight is:70
The total no. of objects added are: 5

1.Add
2.Display
3.Delete
4.Exit
Choice:
3
Enter no. of record to be deleted
4
Record deleted Successfully....!
1.Add
2.Display
3.Delete
4.Exit
Choice:
2
1. Colour: Red and  Weight: 10
The total weight is:40
The total no. of objects added are: 4

2. Colour: Red and  Weight: 10
The total weight is:40
The total no. of objects added are: 4

3. Colour: green and  Weight: 10
The total weight is:40
The total no. of objects added are: 4

4. Colour: yellow and  Weight: 10
The total weight is:40
The total no. of objects added are: 4

1.Add
2.Display
3.Delete
4.Exit
Choice:
4

*/
