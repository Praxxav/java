import java.util.Scanner;

	abstract class Car_Factory{	
		
		
		String compnay,car_name;
		double budget;
		
		
		abstract void getprice(double price);
		abstract void detail(String company_name,String car_name);
		abstract void accessories();
		
		
		void input() {
			Scanner scan =new Scanner (System.in);
			System.out.print("Company- ");
			 compnay=scan.next();
			System.out.print("Car- ");
			 car_name=scan.next();
			System.out.print("Rough Budget(in Lakhs)- ");
			 budget=scan.nextDouble();
		}
		void display(Car_Factory obj1) {
			
			obj1.getprice(budget);
			System.out.println("\n-----------------------------------");
			obj1.detail(compnay, car_name);
			System.out.println("\n-----------------------------------");
			obj1.accessories();
			System.out.println("\n-----------------------------------");
		}

	}

	

