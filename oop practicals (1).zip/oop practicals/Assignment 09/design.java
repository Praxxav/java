import java.util.Scanner;

public class design {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		int ch;
		
		Car_Factory obj;
		while(true){
			//menu driven
			System.out.println("Which Car you want to See?- ");
			System.out.println("\n\t1.Hatchback\n\t2.Sedan Car\n\t3.SUV \n\t4.Exit");
			ch=scan.nextInt();
			System.out.println();
			//switch case
			switch(ch) {
	
				case 1:
					obj= new Hatchback (); 
					obj.input();
					obj.display(obj);
					break;
					
				case 2:
					obj= new Sedan1();
					obj.input();
					obj.display(obj);
					break;
					
				case 3:
					obj= new SUV();
					obj.input();
					obj.display(obj);
					break;
					
				case 4:
					System.out.println("\n-----------------------------------");
					return;
					
				default:
					System.out.println("INVALID CHOICE !!");//default 
					System.out.println("\n-----------------------------------");
					break;
				
			}
		}
	}

}

/*
 output:
 
 Which Car you want to See?- 

	1.Hatchback
	2.Sedan Car
	3.SUV 
	4.Exit
1

Company- hatchback
Car- hatchback
Rough Budget(in Lakhs)- 5

-----------------------------------
Company- hatchback
Name of Car- hatchback
Color- Black/White/Orange/Red
Fuel- Petrol
Gears- Manual

-----------------------------------
Types of Tyres- Alloy Wheels
Airbags- Yes
Back Wiper- Yes
Side Mirror- Two
Touch Screen Music Player- Yes

-----------------------------------
Which Car you want to See?- 

	1.Hatchback
	2.Sedan Car
	3.SUV 
	4.Exit
2

Company- volkwagan
Car- Sedan
Rough Budget(in Lakhs)- 12

-----------------------------------
Company- volkwagan
Name of Car- Sedan
Color- Black/White/Orange/Red
Fuel- Petrol/Diesel
Gears- Auto/Manual

-----------------------------------
Types of Tyres- Alloy Wheels
Airbags- YES
Back Wiper- YES
Side Mirror- Two
Touch Screen Music Player- YES
Roof Window- Yes

-----------------------------------
Which Car you want to See?- 

	1.Hatchback
	2.Sedan Car
	3.SUV 
	4.Exit
4


-----------------------------------

 */
