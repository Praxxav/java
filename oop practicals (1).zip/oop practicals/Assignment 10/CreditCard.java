import java.util.Scanner;

interface PaymentProcessor
{

	  void pay(int amount);//interface method pay

}

	class CreditCard implements PaymentProcessor {
		  Scanner sc =new Scanner (System.in);
		  String name,ExpDate;
		  double CardNo;
		  
		  
		  CreditCard(){ 
			  super();//calling parent class constructor
			  System.out.println("----------------------------------------------------------");
			  System.out.print("\tCard holder Name :: ");//printing on console
			  this.name =sc.next();//taking Card holder Name as input from user
			  System.out.print("\tCard Number :: ");//printing on console
			  this.CardNo =sc.nextDouble();//taking Card Number as input from user
			  System.out.print("\tCard Expire Date :: ");//printing on console
			  this.ExpDate =sc.next();//taking Card Expire Date as input from user
			  System.out.println("----------------------------------------------------------");
		  }
		  
		  @Override 
		  public void pay(int amount) { 	//method for payment
			  System.out.println("----------------------------------------------------------");
		      System.out.println("Paying through CreditCard payment: Charging $" + amount);
		      System.out.println("----------------------------------------------------------");
		  }
		  

	}


	

