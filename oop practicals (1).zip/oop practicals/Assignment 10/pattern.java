import java.util.Scanner;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				int c,amt=0;
				Order order;
				Scanner sc = new Scanner(System.in);
				
				while(true) 
				{//while loop for menu driven
					System.out.println();
					
					System.out.println("**** SHOPING CART ****");
					System.out.print("1.Credit Card \n2.PayPal \n3.BitCoin \n4.Exit");
					System.out.print("\n\nEnter the Choice ::");
					c=sc.nextInt();//taking input from user
					System.out.println("----------------------------------------------------------");
					if(c==1||c==2||c==3) 
					{
						 System.out.print("\nEnter amount tobe Tranfer :: ");
						 amt = sc.nextInt();//taking amt as input from user
						 System.out.println("----------------------------------------------------------");
					}
					//switch case
					switch(c) 
					{
					 case 1://for input c ==1
						  order = new Order(amt, new CreditCard());//creating obj of order class
						  order.process();//calling process method of order class
						 break;
						 
					 case 2://for input c == 2
						  order = new Order(amt, new PayPal());//creating obj of order class
						  order.process();//calling process method of order class
						 break;
						 
					 case 3://for input c == 3
						  order = new Order(amt, new BitCoin());//creating obj of order class
						  order.process();//calling process method of order class
						 break;
						 
					 case 4:
						 System.out.println("\nThank you For Shopping !!!! ");//printing on console
						 System.out.println("----------------------------------------------------------");
						 return;//stop execution of program
						 
					default:
						System.out.println("Invalid Payment Mode !!!");// default
						System.out.println("----------------------------------------------------------");
					 }
				}
			}
		


	}

/*
 output:
**** SHOPING CART ****
1.Credit Card 
2.PayPal 
3.BitCoin 
4.Exit

Enter the Choice ::
1
----------------------------------------------------------

Enter amount tobe Tranfer :: 
3000
----------------------------------------------------------
----------------------------------------------------------
	Card holder Name :: abc
	Card Number :: 123
	Card Expire Date :: 2312
----------------------------------------------------------
----------------------------------------------------------
Paying through CreditCard payment: Charging $3000
----------------------------------------------------------

**** SHOPING CART ****
1.Credit Card 
2.PayPal 
3.BitCoin 
4.Exit

Enter the Choice ::2
----------------------------------------------------------

Enter amount tobe Tranfer :: 500
----------------------------------------------------------

Checking Internet Connection........
----------------------------------------------------------
Paying through PayPal payment: Charging $500
----------------------------------------------------------

**** SHOPING CART ****
1.Credit Card 
2.PayPal 
3.BitCoin 
4.Exit

Enter the Choice ::3
----------------------------------------------------------

Enter amount tobe Tranfer :: 60000
----------------------------------------------------------

Enter Transaction 'Input Address' :: xyz
----------------------------------------------------------
Paying through BitCoin payment: Charging $60000
----------------------------------------------------------

**** SHOPING CART ****
1.Credit Card 
2.PayPal 
3.BitCoin 
4.Exit

Enter the Choice ::4
----------------------------------------------------------

Thank you For Shopping !!!! 
----------------------------------------------------------

 */
